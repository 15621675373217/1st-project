package next.simplecalculator;

import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        EditText editTextFirst = findViewById(R.id.editTextFirst);
        EditText editTextSecond = findViewById(R.id.editTextSecond);
        TextView buttonAdd = findViewById(R.id.buttonAdd);
        TextView buttonSub = findViewById(R.id.buttonSub);
        TextView buttonMul = findViewById(R.id.buttonMul);
        TextView buttonDiv = findViewById(R.id.buttonDiv);
        TextView buttonClear = findViewById(R.id.buttonClear);
        TextView resultViewResult = findViewById(R.id.resultViewResult);

        buttonAdd.setOnClickListener(v -> {
            String firstNumberText = editTextFirst.getText().toString().trim();
            String secondNumberText = editTextSecond.getText().toString();
            if(firstNumberText.isEmpty() || secondNumberText.isEmpty()){
                resultViewResult.setText(getString(R.string.Empty));
                return;
            }

            double firstNumber = Double.parseDouble(firstNumberText);
            double secondNumber = Double.parseDouble(secondNumberText);
            double result = firstNumber + secondNumber;
            resultViewResult.setText(String.valueOf(result));
        });
        buttonSub.setOnClickListener(v -> {
            String firstNumberText = editTextFirst.getText().toString().trim();
            String secondNumberText = editTextSecond.getText().toString();
            if(firstNumberText.isEmpty() || secondNumberText.isEmpty()){
                resultViewResult.setText(getString(R.string.Empty));
                return;
            }
            double firstNumber = Double.parseDouble(firstNumberText);
            double secondNumber = Double.parseDouble(secondNumberText);
            double result = firstNumber - secondNumber;
            resultViewResult.setText(String.valueOf(result));
        });
        buttonMul.setOnClickListener(v -> {
            String firstNumberText = editTextFirst.getText().toString().trim();
            String secondNumberText = editTextSecond.getText().toString();
            if(firstNumberText.isEmpty() || secondNumberText.isEmpty()){
                resultViewResult.setText(getString(R.string.Empty));
                return;
            }
            double firstNumber = Double.parseDouble(firstNumberText);
            double secondNumber = Double.parseDouble(secondNumberText);
            double result = firstNumber * secondNumber;
            resultViewResult.setText(String.valueOf(result));
        });
        buttonDiv.setOnClickListener(v -> {
            String firstNumberText = editTextFirst.getText().toString().trim();
            String secondNumberText = editTextSecond.getText().toString();
            if(firstNumberText.isEmpty() || secondNumberText.isEmpty()){
                resultViewResult.setText(getString(R.string.Empty));
                return;
            }
            double firstNumber = Double.parseDouble(firstNumberText);
            double secondNumber = Double.parseDouble(secondNumberText);
            double result = firstNumber / secondNumber;
            resultViewResult.setText(String.valueOf(result));
        });
        buttonClear.setOnClickListener(v -> {
            editTextFirst.setText("");
            editTextSecond.setText("");
            resultViewResult.setText(getString(R.string.result));
        });



    }
}